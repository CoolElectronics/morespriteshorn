function love.conf(t)
    t.window.title = "Everhorn"
    t.window.width = 1280
    t.window.height = 720
    t.window.resizable = true
end
